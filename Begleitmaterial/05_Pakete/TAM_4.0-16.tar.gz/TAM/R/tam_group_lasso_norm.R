## File Name: tam_group_lasso_norm.R
## File Version: 0.03

tam_group_lasso_norm <- function(x)
{
    res <- sqrt(sum(x^2))
    return(res)
}
