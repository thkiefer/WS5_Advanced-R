## File Name: tam_fisherz.R
## File Version: 0.01

tam_fisherz <- function(x)
{
    0.5*log( (1+x)/ (1-x) )
}
