## File Name: plot.tam.pv.mcmc.R
## File Version: 0.01

plot.tam.pv.mcmc <- function(x, ...)
{
    plot( x$parameter_samples, ... )
}
