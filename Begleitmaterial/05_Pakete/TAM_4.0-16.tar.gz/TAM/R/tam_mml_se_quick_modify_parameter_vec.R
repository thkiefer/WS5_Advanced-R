## File Name: tam_mml_se_quick_modify_parameter_vec.R
## File Version: 0.04

tam_mml_se_quick_modify_parameter_vec <- function(pp)
{
    if (pp==1){
        vec <- 1:3
    } else {
        vec <- 2:3
    }
    return(vec)
}
