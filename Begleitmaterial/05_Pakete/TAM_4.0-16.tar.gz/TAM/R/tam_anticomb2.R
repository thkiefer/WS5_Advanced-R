## File Name: tam_anticomb2.R
## File Version: 0.01

tam_anticomb2 <- function(H)
{
    D0 <- round( sqrt( 2*H + .25 ) - .5 )
    return(D0)
}
