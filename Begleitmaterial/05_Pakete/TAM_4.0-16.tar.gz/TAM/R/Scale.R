## File Name: Scale.R
## File Version: 9.03



#####################################################
# S3 method Scale
Scale <- function (object, ...)
{
    UseMethod("Scale")
}
#####################################################
