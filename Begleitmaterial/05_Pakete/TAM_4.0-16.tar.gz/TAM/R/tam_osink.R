## File Name: tam_osink.R
## File Version: 0.05

tam_osink <- function(file, suffix=".Rout")
{
    CDM::osink( file=file, suffix=suffix )
}
