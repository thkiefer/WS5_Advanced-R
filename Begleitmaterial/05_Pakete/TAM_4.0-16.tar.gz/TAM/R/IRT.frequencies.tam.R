## File Name: IRT.frequencies.tam.R
## File Version: 0.05

TAM_IRT_frequencies_wrapper <- function( object, ...){
    CDM::IRT_frequencies_wrapper( object=object, ...)
}

IRT.frequencies.tam.mml <- TAM_IRT_frequencies_wrapper
IRT.frequencies.tamaan <- TAM_IRT_frequencies_wrapper
IRT.frequencies.tam.mml.3pl <- TAM_IRT_frequencies_wrapper
